<?php

use App\Models\Employer;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\JobController;

Route::view('/', 'home');
Route::view('/contact', 'contact');

Route::resource('/jobs', JobController::class);

Route::get('/employers', function () {
    $employers = Employer::with('jobs')->paginate(20);

    return view('/employers',[
        'employers' => $employers
    ]);
});

route::get('/employers/{id}', function ($id) {
   $employer = Employer::find($id);

   return view('employer', ['employer' => $employer]);
});
