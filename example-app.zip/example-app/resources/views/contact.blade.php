<x-layout>
    <x-slot:heading>
        Contact Page
    </x-slot:heading>
    <h1 class="text-gray-200">Hello from the Contact page.</h1>
</x-layout>
