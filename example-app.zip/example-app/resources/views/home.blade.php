<x-layout>
    <x-slot:heading>
        Home Page
    </x-slot:heading>
    <h1 class="text-gray-200">Welcome to the Home Page.</h1>
</x-layout>
