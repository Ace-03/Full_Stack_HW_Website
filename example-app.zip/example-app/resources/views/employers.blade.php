<x-layout>
    <x-slot:heading>
        Employers
    </x-slot:heading>

    <div class="space-y-4">
        @foreach($employers as $employer)
            <a href="/employers/{{ $employer['id'] }}" class="block px-4 py-6 border border-b-gray-100 rounded-lg text-gray-200">
                <div class="font-bold text-sm">
                    <strong>{{ $employer->name }}</strong>
                </div>
            </a>
        @endforeach

            <div>
                {{ $employers->links() }}
            </div>
    </div>
</x-layout>
