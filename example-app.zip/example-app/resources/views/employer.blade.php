<x-layout>
    <x-slot:heading>
        {{$employer['name'] }}
    </x-slot:heading>

    <h2 class="font-bold text-lg text-gray-200">Now Hiring!</h2>

    <p class="text-gray-200"> {{$employer->created_at}}</p>

</x-layout>
